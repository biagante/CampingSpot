package androidx.core.view;

/* renamed from: androidx.core.view.-$$Lambda$ViewCompat$a2AAj7NVELdYVvmIIdgd_g49NQw  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$ViewCompat$a2AAj7NVELdYVvmIIdgd_g49NQw implements OnReceiveContentViewBehavior {
    public static final /* synthetic */ $$Lambda$ViewCompat$a2AAj7NVELdYVvmIIdgd_g49NQw INSTANCE = new $$Lambda$ViewCompat$a2AAj7NVELdYVvmIIdgd_g49NQw();

    private /* synthetic */ $$Lambda$ViewCompat$a2AAj7NVELdYVvmIIdgd_g49NQw() {
    }

    public final ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat) {
        return ViewCompat.lambda$static$0(contentInfoCompat);
    }
}
